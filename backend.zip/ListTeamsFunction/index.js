const axios = require("axios");

module.exports = async function (context, req) {
  context.log("Azure DevOps ListTeamsFunction triggered");

  try {
    const pat = process.env.AZURE_DEVOPS_PAT;
    const org = process.env.AZURE_DEVOPS_ORG;

    if (!org) {
      throw new Error("Variável de ambiente AZURE_DEVOPS_ORG não definida");
    }
    if (!pat) {
      throw new Error("Variável de ambiente AZURE_DEVOPS_PAT não definida");
    }

    const url = `https://dev.azure.com/${org}/_apis/teams?api-version=4.1-preview.2`;

    const encodedPat = Buffer.from(":" + pat).toString("base64");

    const response = await axios.get(url, {
      headers: {
        Authorization: `Basic ${encodedPat}`,
        Accept: "application/json",
      },
    });

    const teams = response.data.value;

    // retorno enxuto
    const result = teams.map((team) => ({
      id: team.id,
      name: team.name,
      description: team.description,
      projectId: team.projectId,
    }));

    context.res = {
      status: 200,
      body: result,
    };
  } catch (err) {
    context.log.error("Erro ao acessar equipes do Azure DevOps:", err);
    context.res = {
      status: 500,
      body: `Erro ao acessar equipes do Azure DevOps: ${err.message}`,
    };
  }
};
