const sql = require("mssql");

module.exports = async function (context, req) {
  context.log("Azure Function CreateAtividadeFunction triggered");

  const { organizacao, projeto, atividade } = req.body;

  if (!organizacao || !projeto || !atividade) {
    context.res = {
      status: 400,
      body: "Por favor, informe organizacao, projeto e atividade no corpo da requisição.",
    };
    return;
  }

  try {
    // use variáveis de ambiente para segurança
    const dbConfig = {
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      server: process.env.DB_SERVER, // ex: apontamentosdb.database.windows.net
      database: process.env.DB_NAME,
      options: {
        encrypt: true,
      },
    };

    // conecta
    await sql.connect(dbConfig);

    // insere
    await sql.query`
      INSERT INTO Atividades (Organizacao, Projeto, Atividade)
      VALUES (${organizacao}, ${projeto}, ${atividade})
    `;

    context.res = {
      status: 201,
      body: "Atividade inserida com sucesso!",
    };
  } catch (err) {
    context.log.error("Erro ao inserir atividade:", err);
    context.res = {
      status: 500,
      body: `Erro ao inserir atividade: ${err.message}`,
    };
  } finally {
    sql.close(); // fecha a conexão
  }
};
