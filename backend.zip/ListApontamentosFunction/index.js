const sql = require("mssql");

module.exports = async function (context, req) {
  context.log("ListApontamentosFunction triggered");

  try {
    const connStr = process.env.SQL_CONNECTION_STRING;

    if (!connStr) {
      throw new Error(
        "Variável de ambiente SQL_CONNECTION_STRING não definida"
      );
    }

    const pool = await sql.connect(connStr);

    const result = await pool.request().query(`
      SELECT
        a.Id,
        a.Organizacao,
        a.Projeto,
        a.Usuario,
        a.DataApontamento,
        a.Horas,
        a.Minutos,
        a.Comentario,
        atv.Id as AtividadeId,
        atv.Atividade as AtividadeNome
      FROM
        Apontamentos a
      INNER JOIN
        Atividades atv ON a.AtividadeId = atv.Id
      ORDER BY
        a.DataApontamento DESC
    `);

    context.res = {
      status: 200,
      body: result.recordset,
    };
  } catch (err) {
    context.log.error("Erro ao listar apontamentos:", err);
    context.res = {
      status: 500,
      body: `Erro ao listar apontamentos: ${err.message}`,
    };
  }
};
