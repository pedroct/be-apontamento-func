const sql = require("mssql");

module.exports = async function (context, req) {
  context.log("Azure Function ListAtividadesFunction triggered");

  const connectionString = process.env.SQL_CONNECTION_STRING;

  try {
    await sql.connect(connectionString);

    const result = await sql.query`
      SELECT Id, Organizacao, Projeto, Atividade, DataCriacao 
      FROM Atividades
      ORDER BY DataCriacao DESC
    `;

    context.res = {
      status: 200,
      body: result.recordset,
    };
  } catch (err) {
    context.log.error("Erro ao consultar o banco de dados:", err);
    context.res = {
      status: 500,
      body: `Erro ao acessar o banco de dados: ${err.message}`,
    };
  } finally {
    sql.close();
  }
};
