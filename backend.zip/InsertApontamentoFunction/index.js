const sql = require("mssql");

module.exports = async function (context, req) {
  context.log("InsertApontamentoFunction triggered");

  try {
    const connStr = process.env.SQL_CONNECTION_STRING;

    if (!connStr) {
      throw new Error(
        "Variável de ambiente SQL_CONNECTION_STRING não definida"
      );
    }

    // conecta no SQL
    const pool = await sql.connect(connStr);

    // obtém dados do body
    const {
      organizacao,
      projeto,
      usuario,
      dataApontamento,
      horas,
      minutos,
      comentario,
      atividadeId,
    } = req.body;

    if (
      !organizacao ||
      !projeto ||
      !usuario ||
      !dataApontamento ||
      !horas ||
      !minutos ||
      !atividadeId
    ) {
      context.res = {
        status: 400,
        body: "Parâmetros obrigatórios ausentes",
      };
      return;
    }

    await pool
      .request()
      .input("Organizacao", sql.NVarChar, organizacao)
      .input("Projeto", sql.NVarChar, projeto)
      .input("Usuario", sql.NVarChar, usuario)
      .input("DataApontamento", sql.Date, dataApontamento)
      .input("Horas", sql.Int, horas)
      .input("Minutos", sql.Int, minutos)
      .input("Comentario", sql.NVarChar, comentario || "")
      .input("AtividadeId", sql.Int, atividadeId).query(`
        INSERT INTO Apontamentos
          (Organizacao, Projeto, Usuario, DataApontamento, Horas, Minutos, Comentario, AtividadeId)
        VALUES
          (@Organizacao, @Projeto, @Usuario, @DataApontamento, @Horas, @Minutos, @Comentario, @AtividadeId)
      `);

    context.res = {
      status: 201,
      body: "Apontamento registrado com sucesso",
    };
  } catch (err) {
    context.log.error("Erro ao inserir apontamento:", err);
    context.res = {
      status: 500,
      body: `Erro ao inserir apontamento: ${err.message}`,
    };
  }
};
