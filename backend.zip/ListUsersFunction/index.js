const axios = require("axios");

module.exports = async function (context, req) {
  context.log("Azure DevOps ListUsersFunction triggered");

  try {
    const pat = process.env.AZURE_DEVOPS_PAT;
    const org = process.env.AZURE_DEVOPS_ORG;

    if (!org) {
      throw new Error("Variável de ambiente AZURE_DEVOPS_ORG não definida");
    }
    if (!pat) {
      throw new Error("Variável de ambiente AZURE_DEVOPS_PAT não definida");
    }

    const url = `https://vsaex.dev.azure.com/${org}/_apis/userentitlements?api-version=4.1-preview.1`;

    const encodedPat = Buffer.from(":" + pat).toString("base64");

    const response = await axios.get(url, {
      headers: {
        Authorization: `Basic ${encodedPat}`,
        Accept: "application/json",
      },
    });

    const users = response.data.value;

    const result = users.map((user) => {
      const displayName = user.user.displayName;
      const email = user.user.mailAddress;

      // se displayName parecer código (8 letras/números), usa o email como fallback
      const isCode = /^[A-Z0-9]{8}$/i.test(displayName);
      const safeName = isCode ? email : displayName;

      const avatar = user.user._links?.avatar?.href || null;

      return {
        email,
        name: safeName,
        avatar,
      };
    });

    context.res = {
      status: 200,
      body: result,
    };
  } catch (err) {
    context.log.error("Erro ao acessar usuários do Azure DevOps:", err);
    context.res = {
      status: 500,
      body: `Erro ao acessar usuários do Azure DevOps: ${err.message}`,
    };
  }
};
