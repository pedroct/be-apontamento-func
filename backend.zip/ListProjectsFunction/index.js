const axios = require("axios");

module.exports = async function (context, req) {
  context.log("Azure DevOps ListProjectsFunction triggered");

  try {
    const pat = process.env.AZURE_DEVOPS_PAT;
    const org = process.env.AZURE_DEVOPS_ORG;

    if (!org) {
      throw new Error("Variável de ambiente AZURE_DEVOPS_ORG não definida");
    }
    if (!pat) {
      throw new Error("Variável de ambiente AZURE_DEVOPS_PAT não definida");
    }

    const url = `https://dev.azure.com/${org}/_apis/projects?api-version=4.1`;

    const encodedPat = Buffer.from(":" + pat).toString("base64");

    const response = await axios.get(url, {
      headers: {
        Authorization: `Basic ${encodedPat}`,
        Accept: "application/json",
      },
    });

    const projects = response.data.value;

    const result = projects.map((project) => ({
      id: project.id,
      name: project.name,
      description: project.description || "",
      state: project.state,
      url: project.url,
    }));

    context.res = {
      status: 200,
      body: result,
    };
  } catch (err) {
    context.log.error("Erro ao acessar projetos do Azure DevOps:", err);
    context.res = {
      status: 500,
      body: `Erro ao acessar projetos do Azure DevOps: ${err.message}`,
    };
  }
};
