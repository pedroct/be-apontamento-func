const axios = require("axios");

module.exports = async function (context, req) {
  context.log("Azure DevOps GetWorkItemFunction triggered");

  try {
    const pat = process.env.AZURE_DEVOPS_PAT;
    const org = process.env.AZURE_DEVOPS_ORG;

    const project = req.query.project || req.body?.project;
    const workItemId = req.query.id || req.body?.id;

    if (!org) throw new Error("AZURE_DEVOPS_ORG não definida no ambiente.");
    if (!pat) throw new Error("AZURE_DEVOPS_PAT não definida no ambiente.");
    if (!project) throw new Error("Parâmetro 'project' é obrigatório.");
    if (!workItemId) throw new Error("Parâmetro 'id' é obrigatório.");

    const url = `https://dev.azure.com/${org}/${project}/_apis/wit/workitems/${workItemId}?api-version=7.1`;

    const encodedPat = Buffer.from(":" + pat).toString("base64");

    const response = await axios.get(url, {
      headers: {
        Authorization: `Basic ${encodedPat}`,
        Accept: "application/json",
      },
    });

    context.res = {
      status: 200,
      body: response.data,
    };
  } catch (err) {
    context.log.error("Erro ao acessar Work Item:", err);
    context.res = {
      status: 500,
      body: `Erro ao acessar Work Item: ${err.message}`,
    };
  }
};
